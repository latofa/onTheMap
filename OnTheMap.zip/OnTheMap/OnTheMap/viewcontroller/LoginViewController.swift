//
//  LoginViewController.swift
//  OnTheMap
//
//  Created by Mac on 29/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController  , UITextFieldDelegate{
    
    @IBOutlet weak var UserEmail: UITextField!
    @IBOutlet weak var UserPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func Signin(_ sender: Any) {
        
        
        
        if UserEmail.text == "" || UserPassword.text == "" {
            
            let alert = UIAlertController(title: "Alert", message: "Please enter your user name and password", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }else {
            
            let email = UserEmail.text
            let password = UserPassword.text
            
            let jsonBody = UdacitySessionBody(udacity: Udacity(username: email!, password: password!))
            
            StudentAuthintication.sharedInstance().authenticateUser(self, jsonBody: jsonBody) { (success,errorString) in
                DispatchQueue.main.async {
                    if success {
                        
                        let controller = self.storyboard!.instantiateViewController(withIdentifier: "MapRoot")
                        self.present(controller, animated: true, completion: nil)
                    }else {
                        
                        let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        
                    }
                }
                
            }
            
        }
    }
    @IBAction func Signup(_ sender: Any) {
        
        
        let url = NSURL(string:"https://www.udacity.com/account/auth#!/signup")! as URL
        
        LoginViewController.openUrl(url:url )
    }
    
    
    public static func  openUrl(url:URL){
        
        
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        
    }
    
    struct JsonBody : Codable {
        let username:String
        let password:String
    }
    
}

