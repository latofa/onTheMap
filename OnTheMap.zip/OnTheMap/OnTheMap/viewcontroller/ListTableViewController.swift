//
//  ListTableViewController.swift
//  OnTheMap
//
//  Created by Mac on 03/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit


class ListTableViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {
    
    
    @IBOutlet weak var Table: UITableView!
    
    var userArray = [Any?]()
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        getusersInfo()
    }
    
    @IBAction func Refresh(_ sender: Any) {
        
        getusersInfo()
    }
    
    
    @IBAction func AddLocation(_ sender: Any) {
        
        
        
        MapAutinitication.sharedInstance().getuserDataByUniqueKey { (success, objectID, errorString) in
            
            if success {
                
                if objectID == nil {
                    DispatchQueue.main.async {
                        
                        let controller = self.storyboard!.instantiateViewController(withIdentifier: "SearchLocation")
                        self.present(controller, animated: true, completion: nil)
                        
                        
                    }
                }else {
                    
                    let alert = UIAlertController(title: "Alert", message: (StudentAuthintication.sharedInstance().userName!)+" Has Already Posted a Stdent Location. Whould you Like to Overwrite Thier Location?", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                    let controller = self.storyboard!.instantiateViewController(withIdentifier: "SearchLocation")
                    self.present(controller, animated: true, completion: nil)
                    
                    
                }
                
            }else {
                let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    @IBAction func Logout(_ sender: Any) {
        
        StudentAuthintication.sharedInstance().deleteSession { (success, sessionID, errorString) in
            
            DispatchQueue.main.async {
                if success {
                    let controller = self.storyboard!.instantiateViewController(withIdentifier: "LoginVC")
                    self.present(controller, animated: true, completion: nil)
                    
                }else {
                    
                    let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
            
        }
    }
    
    func getusersInfo(){
        userArray.removeAll()
        
        MapAutinitication.sharedInstance().getAllDataFormUsers { (success, usersUnfo, errorString) in
            
            
            if success {
                
                
                self.userArray = usersUnfo as! [results]
                
                DispatchQueue.main.async {
                    
                    
                    self.Table.reloadData()
                }
                
            }else {
                DispatchQueue.main.async {
                    
                }
                let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
                
            }
            
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return userArray.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "usersCell") as! ListTableCell
        
        
        cell.tablCell(userInfo: userArray[indexPath.row] as! results)
        
        return cell
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dataArray = self.userArray as! [results]
        
        if let urlString = dataArray[indexPath.row].mediaURL,
            let url = URL(string: urlString){
            
            LoginViewController.openUrl(url:url)
            
            
        }
    }
    
    
}



