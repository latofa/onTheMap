//
//  MapViewController.swift
//  OnTheMap
//
//  Created by Mac on 01/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//


import UIKit
import MapKit


class MapViewController: UIViewController , MKMapViewDelegate {
    
    @IBOutlet weak var Map: MKMapView!
    
    
    private var annotations = [MKPointAnnotation]()
    
    var userArray = [Any?]()
    
    override func viewDidLoad() {
        
        self.navigationController?.isNavigationBarHidden = false
        self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getUsersInfo()
    }
    
    @IBAction func Logout(_ sender: Any) {
        
        StudentAuthintication.sharedInstance().deleteSession { (success, sessionID, errorString) in
            
            DispatchQueue.main.async {
                if success {
                    let controller = self.storyboard!.instantiateViewController(withIdentifier: "LoginVC")
                    self.present(controller, animated: true, completion: nil)
                    
                }else {
                    
                    let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
            
        }
    }
    @IBAction func AddLocation(_ sender: Any) {
        
        MapAutinitication.sharedInstance().getuserDataByUniqueKey { (success, objectID, errorString) in
            
            if success {
                
                if objectID == nil {
                    DispatchQueue.main.async {
                        
                        let controller = self.storyboard!.instantiateViewController(withIdentifier: "SearchLocation")
                        self.present(controller, animated: true, completion: nil)
                        
                        
                    }
                }else {
                    
                    let alert = UIAlertController(title: "Alert", message: (StudentAuthintication.sharedInstance().userName!)+" Has Already Posted a Stdent Location. Whould you Like to Overwrite Thier Location?", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                    let controller = self.storyboard!.instantiateViewController(withIdentifier: "SearchLocation")
                    self.present(controller, animated: true, completion: nil)
                    
                    
                }
                
            }else {
                let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    
    
    
    @IBAction func Refresh(_ sender: Any) {
        
        getUsersInfo()
    }
    func getUsersInfo(){
        
        annotations.removeAll()
        userArray.removeAll()
        let allAnnotations = self.Map.annotations
        self.Map.removeAnnotations(allAnnotations)
        
        
        MapAutinitication.sharedInstance().getAllDataFormUsers { (success, usersInfo, errorString) in
            
            if success {
                
                self.userArray = usersInfo as! [results]
                
                self.organizingUsersData(userArray: self.userArray as! [results])
                
            }else {
                
                let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
        
    }
    
    
    func organizingUsersData(userArray:[results]){
        
        print("organize")
        for l in userArray {
            
            
            if let latitude = l.latitude , let longitude = l.longitude , let first = l.firstName ,let last = l.lastName , let URL = l.mediaURL {
                
                
                let long = CLLocationDegrees(longitude)
                let lat = CLLocationDegrees(latitude)
                
                let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: long)
                
                let annotation = MKPointAnnotation()
                annotation.coordinate = coordinate
                annotation.title = "\(first) \(last)"
                annotation.subtitle = URL
                
                self.annotations.append(annotation)
                
                
                
            }
            DispatchQueue.main.async {
                self.Map.addAnnotations(self.annotations)
                
            }
            
            
        }
        
    }
    
    
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        print("here 1")
        let reuseId = "pin"
        
        var pinView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView
        
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            pinView!.canShowCallout = true
            pinView!.pinTintColor = .red
            pinView!.rightCalloutAccessoryView = UIButton(type: .infoDark)
        }
        else {
            pinView!.annotation = annotation
        }
        
        
        return pinView
        
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        print("pin taped")
        if control == view.rightCalloutAccessoryView {
            
            if let  userUrl = view.annotation?.subtitle! {
                let url = URL(string: userUrl)
                LoginViewController.openUrl(url:url! )
                
            }
        }
    }
    
    func mapView(mapView: MKMapView, annotationView: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        print("pin taped")
        if control == annotationView.rightCalloutAccessoryView {
            let userUrl = annotationView.annotation?.subtitle
            let stringUrl = userUrl
            let url = URL(string: stringUrl as! String)
            LoginViewController.openUrl(url: url!)
            
        }
    }
    
    
    
}




