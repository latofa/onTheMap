//
//  AddLocation.swift
//  OnTheMap
//
//  Created by Mac on 02/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import MapKit


class AddLocationViewController: UIViewController {
    
    
    var latitude:Double?
    var longitude:Double?
    var mapS:String?
    var URL:String?
    
    @IBOutlet weak var map: MKMapView!
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        createAnnotation()
        
    }
    
    
    @IBAction func Back(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
        let controller = self.storyboard!.instantiateViewController(withIdentifier: "SearchLocation")
        self.present(controller, animated: true, completion: nil)
    }
    
    @IBAction func finish(_ sender: Any) {
        
        print("new location")
        if MapAutinitication.sharedInstance().objectId == nil {
            newStudentLocation()
        }else {
            
            updateStudentLocation()
            
        }
    }
    
    
    func newStudentLocation(){
        
        if let userName = StudentAuthintication.sharedInstance().userName {
            var components = userName.components(separatedBy: " ")
            if(components.count > 0)
            {
                let firstN = components.removeFirst()
                let lastN = components.joined(separator: " ")
                
                
                let jsonBody = StudentInfo(uniqueKey:StudentAuthintication.sharedInstance().userID! , firstName:firstN, lastName:lastN ,mapString:mapS!,mediaURL:URL! ,latitude:latitude! , longitude:longitude!)
                
                
                MapAutinitication.sharedInstance().postUserLocation(jsonBody: jsonBody) { (success, errorString) in
                    
                    if success {
                        print(success)
                        
                        DispatchQueue.main.async {
                            self.dismiss(animated: true, completion: nil)
                            
                            let controller = self.storyboard!.instantiateViewController(withIdentifier: "MapRoot")
                            
                            self.present(controller, animated: true, completion: nil)
                            
                        }
                        
                    }else {
                        
                        let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        
                    }
                    
                }
            }
            
        }
        
        
    }
    
    func updateStudentLocation(){
        
        if let userName = StudentAuthintication.sharedInstance().userName {
            var components = userName.components(separatedBy: " ")
            if(components.count > 0)
            {
                let firstN = components.removeFirst()
                let lastN = components.joined(separator: " ")
                
                
                let jsonBody = StudentInfo(uniqueKey:StudentAuthintication.sharedInstance().userID! , firstName:firstN, lastName:lastN ,mapString:mapS!,mediaURL:URL! ,latitude:latitude! , longitude:longitude!)
                
                
                MapAutinitication.sharedInstance().putUserLocation(jsonBody: jsonBody) { (success, errorString) in
                    
                    if success {
                        print(success)
                        
                        DispatchQueue.main.async {
                            self.dismiss(animated: true, completion: nil)
                            
                            let controller = self.storyboard!.instantiateViewController(withIdentifier: "MapRoot")
                            
                            self.present(controller, animated: true, completion: nil)
                            
                        }
                    }else {
                        
                        let alert = UIAlertController(title: "Alert", message: errorString, preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                }
            }
            
        }
        
        
    }
    
    
    
    func createAnnotation(){
        let annotation = MKPointAnnotation()
        annotation.title = mapS!
        annotation.subtitle = URL!
        annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
        map.addAnnotation(annotation)
        
        let coredinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coredinate, span: span)
        map.setRegion(region, animated: true)
        
    }
}
