//
//  SearchLocationViewController.swift
//  OnTheMap
//
//  Created by Mac on 01/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import MapKit
class SearchLocationViewController: UIViewController{
    
    
    
    @IBOutlet weak var userLocation: UITextField!
    
    @IBOutlet weak var userWebsite: UITextField!
    
    var latitude : Double?
    var longitude : Double?
    
    override func viewDidLoad() {
        self.navigationController?.isNavigationBarHidden = false
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        tabBarController?.tabBar.isHidden = false
    }
    
    @IBAction func Back(_ sender: Any) {
        
        
        DispatchQueue.main.async {
            self.dismiss(animated: true, completion: nil)
            
            let controller = self.storyboard!.instantiateViewController(withIdentifier: "MapRoot")
            
            self.present(controller, animated: true, completion: nil)
            
        }
    }
    
    
    
    @IBAction func findLocation(_ sender: Any) {
        
        if userLocation.text == "" || userWebsite.text == "" {
            
            
            DispatchQueue.main.async {
                
                let alert = UIAlertController(title: "Alert", message: "please enter your location and URL ", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            
            
        }else {
            
            
            let searchRequest = MKLocalSearch.Request()
            searchRequest.naturalLanguageQuery = userLocation.text
            
            let activeSearch = MKLocalSearch(request: searchRequest)
            
            activeSearch.start { (response, error) in
                
                if error != nil {
                    
                    
                    print("Location Error : \(error!.localizedDescription)")
                    
                    let alert = UIAlertController(title: "Alert", message:"Location Not Found", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }else {
                    
                    
                    self.latitude = response?.boundingRegion.center.latitude
                    self.longitude = response?.boundingRegion.center.longitude
                    
                    self.performSegue(withIdentifier: "AddLocationViewController", sender: nil)
                }
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AddLocationViewController"{
            
            print("add location segue")
            let vc = segue.destination as! AddLocationViewController
            
            print("second add location segue")
            vc.mapS = userLocation.text
            vc.URL = userWebsite.text
            vc.latitude = self.latitude
            vc.longitude = self.longitude
            
        }
        
    }
    
    
    
}


extension SearchLocationViewController: UITextFieldDelegate{
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
