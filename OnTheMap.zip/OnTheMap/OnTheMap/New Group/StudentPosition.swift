//
//  StudentPosition.swift
//  OnTheMap
//
//  Created by Mac on 01/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

struct StudentPosition : Codable {
    let results : [results]?
}

struct results : Codable {
    let createdAt:String?
    let firstName:String?
    let lastName:String?
    let latitude:Double?
    let longitude:Double?
    let mapString:String?
    let mediaURL:String?
    let uniqueKey:String?
    let updatedAt:String?
    let objectId:String?
    
}

struct StudentInfo : Codable {
    let uniqueKey:String?
    let firstName:String?
    let lastName:String?
    let mapString:String?
    let mediaURL:String?
    let latitude:Double?
    let longitude:Double?
}

struct StudentLocationsResponse : Codable {
    let createdAt : String?
    let objectId : String?
    
}

struct StudentLocationsUpdateResponse : Codable {
    let createdAt : String?
}




