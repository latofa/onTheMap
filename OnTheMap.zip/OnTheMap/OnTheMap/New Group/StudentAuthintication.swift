//
//  Client.swift
//  OnTheMap
//
//  Created by Mac on 30/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//



import Foundation
import UIKit

class StudentAuthintication : NSObject {
    
    
    
    override init() {
        super.init()
    }
    var urlSession = URLSession.shared
    var userName  : String? = nil
    var sessionID  : String? = nil
    var userID  : String? = nil
    
    class func sharedInstance() -> StudentAuthintication {
        struct Singleton {
            static var sharedInstance = StudentAuthintication()
        }
        return Singleton.sharedInstance
    }
    
    struct Constants {
        
        
        // MARK: URLs
        static let ApiScheme = "https"
        static let ApiHost = "onthemap-api.udacity.com"
        static let ApiPath = "/v1"
        
    }
    
    func taskForGETMethod<D: Decodable>(_ method: String,decode:D.Type, completionHandlerForGET: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        
        var urlComponents = URLComponents()
        urlComponents.scheme = Constants.ApiScheme
        urlComponents.host = Constants.ApiHost
        urlComponents.path = Constants.ApiPath + (method )
        
        let request = NSMutableURLRequest(url: urlComponents.url!)
        
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let error = [NSLocalizedDescriptionKey : "Your Password or Email is uncorrect"]
                completionHandlerForGET(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: error))
                
                return
            }
            
            let data = data
            
            
            let range = 5..<data!.count
            let newData = data!.subdata(in: range)
            
            
            self.covertion(newData, decode:decode,completionHandlerForConvertData: completionHandlerForGET)
            
        }
        
        task.resume()
        
        return task
        
        
    }
    
    
    func taskForPOSTMethod<E: Encodable,D:Decodable>(_ method: String,decode:D.Type?, jsonBody: E, completionHandlerForPOST: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        
        var urlComponents = URLComponents()
        urlComponents.scheme = Constants.ApiScheme
        urlComponents.host = Constants.ApiHost
        urlComponents.path = Constants.ApiPath + (method )
        
        
        let request = NSMutableURLRequest(url: urlComponents.url!)
        
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        let JsonBody = try! JSONEncoder().encode(jsonBody)
        request.httpBody = JsonBody
        
        
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let error = [NSLocalizedDescriptionKey : "Your Password or Email is uncorrect"]
                completionHandlerForPOST(nil, NSError(domain: "taskForPOSTMethod", code: 1, userInfo: error))
                
                return
            }
            
            
            let data = data
            
            
            let range = 5..<data!.count
            let newData = data!.subdata(in: range)
            
            self.covertion(newData, decode: decode!, completionHandlerForConvertData: completionHandlerForPOST)
            
        }
        
        task.resume()
        
        return task
    }
    
    
    //Delete
    func taskForDeleteMethod<D:Decodable>(_ method: String,decode:D.Type?, completionHandlerForDelete: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        var urlComponents = URLComponents()
        urlComponents.scheme = Constants.ApiScheme
        urlComponents.host = Constants.ApiHost
        urlComponents.path = Constants.ApiPath + (method )
        
        
        let request = NSMutableURLRequest(url: urlComponents.url!)
        
        
        request.httpMethod = "Delete"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let error = [NSLocalizedDescriptionKey :  "Your Password or Email is uncorrect"]
                completionHandlerForDelete(nil, NSError(domain: "taskForPOSTMethod", code: 1, userInfo: error))
                return
            }
            
            /* GUARD: Was there any data returned? */
            let data = data
            
            //Remove 5 checter from Response
            let range = 5..<data!.count
            let newData = data!.subdata(in: range) /* subset response data! */
            
            
            self.covertion(newData, decode: decode!, completionHandlerForConvertData: completionHandlerForDelete)
            
        }
        /* 7. Start the request */
        task.resume()
        
        return task
    }
    
    private func covertion<D: Decodable>(_ data: Data,decode:D.Type, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void) {
        
        
        let obj = try! JSONDecoder().decode(decode, from: data)
        completionHandlerForConvertData(obj as AnyObject, nil)
        
        
    }
    
    
    func authenticateUser<E: Encodable>(_ hostViewController: UIViewController,jsonBody: E, completionHandlerForAuth: @escaping (_ success: Bool, _ errorString: String?) -> Void) {
        
        // chain completion handlers for each request so that they run one after the other
        
        
        
        createSession(jsonBody: jsonBody) { (success, sessionID,userID, errorString) in
            
            if success {
                
                print("first success")
                // success! we have the sessionID!
                self.sessionID = sessionID
                self.userID = userID
                
                
                self.getPublicDataForUserID(userID: userID) { (success, userName, errorString) in
                    
                    if success {
                        
                        print("second success")
                        if let userName = userName {
                            self.userName = "\(userName)"
                        }
                        
                        
                    }
                    
                    print("second error")
                    completionHandlerForAuth(success, errorString)
                }
            } else {
                print("first error")
                completionHandlerForAuth(success, errorString)
            }
        }
        
        
    }
    
    
    
    private func createSession<E: Encodable>( jsonBody:E ,completionHandlerForSession: @escaping (_ success: Bool , _ sessionID: String?,_ userID: String?, _ errorString: String?) -> Void) {
        
        
        _ =  taskForPOSTMethod("/session", decode: UdacitySessionResponse.self, jsonBody: jsonBody) { (result, error) in
            
            if let error = error {
                
                print("error=error post")
                completionHandlerForSession(false ,nil ,nil,"\(error.localizedDescription) ")
            }else {
                
                print("error =! error post")
                let newResult = result as! UdacitySessionResponse
                if let sessionID = newResult.session.id , let userID = newResult.account.key  {
                    completionHandlerForSession(true ,sessionID,userID ,nil)
                    
                }else {
                    
                    print("error post")
                    completionHandlerForSession(false ,nil ,nil," \(error!.localizedDescription)")
                    
                }
                
                
            }
        }
        
    }
    
    
    
    
    
    private func getPublicDataForUserID(userID: String?,_ completionHandlerForUserID: @escaping (_ success: Bool,_ userName: String?, _ errorString: String?) -> Void) {
        
        
        /* 2. Make the request */
        
        var mutableMethod: String = "/users/{id}"
        if mutableMethod.range(of: "{\("id")}") != nil {
            print("not nil")
            mutableMethod =  mutableMethod.replacingOccurrences(of: "{\("id")}", with: String(StudentAuthintication.sharedInstance().userID!))
        } else {
            
            print("here is nil")
            mutableMethod = "nil"
        }
        
        
        /* 2. Make the request */
        
        _ = taskForGETMethod(mutableMethod , decode: UdacityUserData.self) { (result, error) in
            
            
            if let error = error {
                
                completionHandlerForUserID(false ,nil ,"\(error.localizedDescription)")
            }else {
                let newResult = result as! UdacityUserData
                if let nickname = newResult.nickname  {
                    
                    completionHandlerForUserID(true ,nickname,nil)
                    
                }else {
                    
                    print("error get")
                    completionHandlerForUserID(false ,nil,"\(String(describing: error?.localizedDescription))")
                    
                }
                
                
            }
        }
        
        
    }
    
    
    func deleteSession(_ completionHandlerForSession: @escaping (_ success: Bool , _ sessionID: String?, _ errorString: String?) -> Void) {
        
        /* 1. Specify parameters, the API method, and the HTTP body (if POST) */
        
        
        /* 2. Make the request */
        
        
        
        _ = taskForDeleteMethod("/session", decode: SessionDelete.self, completionHandlerForDelete: { (result, error) in
            
            if let error = error {
                completionHandlerForSession(false ,nil,"\(error.localizedDescription) ")
            }else {
                let newResult = result as! SessionDelete
                if let sessionID = newResult.session.id  {
                    completionHandlerForSession(true ,sessionID ,nil)
                    
                }else {
                    completionHandlerForSession(false ,nil ," \(error!.localizedDescription)")
                    
                }
                
                
            }
        }
        )
    }
    
    
}




