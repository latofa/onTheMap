//
//  ClientCostraints.swift
//  OnTheMap
//
//  Created by Mac on 30/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

struct StudentConstants {
    
    
    // MARK: URLs
    static let ApiScheme = "https"
    static let ApiHost = "onthemap-api.udacity.com"
    static let ApiPath = "/v1"
    
}
