//
//  ClientCostraints.swift
//  OnTheMap
//
//  Created by Mac on 30/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import Foundation

extension StudentAuthintication{
    
    struct StudentConstants {
        
        
        // MARK: URLs
        static let ApiScheme = "https"
        static let ApiHost = "onthemap-api.udacity.com"
        static let ApiPath = "/v1"
        
    }
    
    
    // MARK: Constants
    struct MapConstants {
        
        // MARK: API Key
        static let ApiKey = "QuWThTdiRmTux3YaDseUSEpUKo7aBYM737yKd4gY"
        static let ApplicationID = "QrX47CA9cyuGewLdsL7o5Eb8iug6Em8ye0dnAbIr"
        
        // MARK: URLs
        static let ApiScheme = "https"
        static let ApiHost = "parse.udacity.com"
        static let ApiPath = "/parse/classes"
        
    }
    
    struct UdacitySessionBody : Codable {
        let udacity : Udacity
    }
    
    struct Udacity : Codable {
        let username:String
        let password:String
    }
    
    
    struct UdacitySessionResponse : Codable {
        let account : Account
        let session : Session
        
    }
    
    struct Account : Codable {
        let registered : Bool?
        let key : String?
    }
    
    struct SessionDelete : Codable {
        let session : Session
    }
    
    struct Session : Codable {
        let id : String?
        let expiration : String?
    }
    
    struct UdacityUserData : Codable {
        let nickname : String?
        
    }
    
    
    
    

    
}
