//
//  Client.swift
//  OnTheMap
//
//  Created by Mac on 30/04/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//


import UIKit
import Foundation


class Student : NSObject {
    
    var urlSession = URLSession.shared
    
    override init() {
        super.init()
    }
    
    
    class func sharedInstance() -> Client {
        struct Singleton {
            static var sharedInstance = Client()
        }
        return Singleton.sharedInstance
    }
    
    struct Constants {
        
        
        // MARK: URLs
        static let ApiScheme = "https"
        static let ApiHost = "onthemap-api.udacity.com"
        static let ApiPath = "/v1"
        
    }
    
    func taskForGETMethod<D: Decodable>(_ method: String,decode:D.Type, completionHandlerForGET: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        /* 1. Set the parameters */
        
        /* 2/3. Build the URL, Configure the request */
        
        var urlComponents = URLComponents()
        urlComponents.scheme = Constants.ApiScheme
        urlComponents.host = Constants.ApiHost
        urlComponents.path = Constants.ApiPath + (method ?? "")
        
        let request = NSMutableURLRequest(url: urlComponents.url!)
        
        /* 4. Make the request */
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            /* GUARD: Did we get a successful 2XX response? */
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let error = [NSLocalizedDescriptionKey : "Your Password or Email is uncorrect"]
                completionHandlerForGET(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: error))
                
                return
            }
            
            /* GUARD: Was there any data returned? */
            let data = data
            
            
            let range = 5..<data!.count
            let newData = data!.subdata(in: range) /* subset response data! */
            
            
            /* 5/6. Parse the data and use the data (happens in completion handler) */
            self.covertion(newData, decode:decode,completionHandlerForConvertData: completionHandlerForGET)
            
        }
        /* 7. Start the request */
        task.resume()
        
        return task
        
        
    }
    
    
    func taskForPOSTMethod<E: Encodable,D:Decodable>(_ method: String,decode:D.Type?, jsonBody: E, completionHandlerForPOST: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
    
        
        var urlComponents = URLComponents()
        urlComponents.scheme = Constants.ApiScheme
        urlComponents.host = Constants.ApiHost
        urlComponents.path = Constants.ApiPath + (method ?? "")
        
      
        let request = NSMutableURLRequest(url: urlComponents.url!)
    
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
      
            let JsonBody = try! JSONEncoder().encode(jsonBody)
            request.httpBody = JsonBody
            
    
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            
        
            /* GUARD: Did we get a successful 2XX response? */
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let error = [NSLocalizedDescriptionKey : "Your Password or Email is uncorrect"]
              completionHandlerForPOST(nil, NSError(domain: "taskForPOSTMethod", code: 1, userInfo: error))
                
                return
            }
            

             let data = data
            
            
            let range = 5..<data!.count
            let newData = data!.subdata(in: range) /* subset response data! */
            
            
            /* 5/6. Parse the data and use the data (happens in completion handler) */
            self.covertion(newData, decode: decode!, completionHandlerForConvertData: completionHandlerForPOST)
            
        }
        /* 7. Start the request */
        task.resume()
        
        return task
    }
    
    
    //Delete
    func taskForDeleteMethod<D:Decodable>(_ method: String,decode:D.Type?, completionHandlerForDelete: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        
        func sendError(_ error: String) {
            print(error)
            let userInfo = [NSLocalizedDescriptionKey : error]
            completionHandlerForDelete(nil, NSError(domain: "taskForPOSTMethod", code: 1, userInfo: userInfo))
        }
        
        
        var urlComponents = URLComponents()
        urlComponents.scheme = Constants.ApiScheme
        urlComponents.host = Constants.ApiHost
        urlComponents.path = Constants.ApiPath + (method ?? "")
        
    
        let request = NSMutableURLRequest(url: urlComponents.url!)
        
        
        request.httpMethod = "Delete"
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let error = [NSLocalizedDescriptionKey :  "Your Password or Email is uncorrect"]
                completionHandlerForDelete(nil, NSError(domain: "taskForPOSTMethod", code: 1, userInfo: error))
                return
            }
            
            /* GUARD: Was there any data returned? */
             let data = data
            
            //Remove 5 checter from Response
            let range = 5..<data!.count
            let newData = data!.subdata(in: range) /* subset response data! */
            
        
            self.covertion(newData, decode: decode!, completionHandlerForConvertData: completionHandlerForDelete)
            
        }
        /* 7. Start the request */
        task.resume()
        
        return task
    }
    
    private func covertion<D: Decodable>(_ data: Data,decode:D.Type, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void) {
        
        
        let obj = try! JSONDecoder().decode(decode, from: data)
        completionHandlerForConvertData(obj as AnyObject, nil)
        
        
    }
    
    
    func authenticateUser<E: Encodable>(_ hostViewController: UIViewController,jsonBody: E, completionHandlerForAuth: @escaping (_ success: Bool, _ errorString: String?) -> Void) {
        
        // chain completion handlers for each request so that they run one after the other
        
        
        
        self.getSession(jsonBody: jsonBody) { (success, sessionID,userID, errorString) in
            
            if success {
                
                // success! we have the sessionID!
                self.sessionID = sessionID
                self.userID = userID
                
                
                self.getPublicDataForUserID(userID: userID) { (success, nickname, errorString) in
                    
                    if success {
                        print("nickname is: \(nickname)")
                        
                        if let nickname = nickname {
                            self.nickname = "\(nickname)"
                        }
                        
                        
                    }
                    
                    completionHandlerForAuth(success, errorString)
                }
            } else {
                completionHandlerForAuth(success, errorString)
            }
        }
        
        
        
        
    }
    
}
