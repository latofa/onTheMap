//
//  MapAutinitication.swift
//  OnTheMap
//
//  Created by Mac on 01/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit
import Foundation


class MapAutinitication : NSObject {
    
    
    var urlSession = URLSession.shared
    var objectId : String? = nil
    
    
    
    // MARK: Initializers
    
    override init() {
        super.init()
    }
    
    class func sharedInstance() -> MapAutinitication {
        struct Singleton {
            static var sharedInstance = MapAutinitication()
        }
        return Singleton.sharedInstance
    }
    
    func taskForGETMethod<D: Decodable>(_ method: String, parameters: [String:AnyObject],decode:D.Type, completionHandlerForGET: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        var components = URLComponents()
        components.scheme = StudentAuthintication.MapConstants.ApiScheme
        components.host = StudentAuthintication.MapConstants.ApiHost
        components.path = StudentAuthintication.MapConstants.ApiPath + (method)
        
        components.queryItems = [URLQueryItem]()
        
        for (key, value) in parameters {
            let queryItem = URLQueryItem(name: key, value: "\(value)")
            components.queryItems!.append(queryItem)
            
        }
        
        
        let url:URL?
        let urlString = components.url!.absoluteString
        if urlString.contains("%22:"){
            
            url = URL(string: "\(urlString.replacingOccurrences(of: "%22:", with: "%22%3A"))")
        }else {
            url = components.url!
        }
        
        
        let request = NSMutableURLRequest(url: url!)
        
        request.addValue(StudentAuthintication.MapConstants.ApplicationID, forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue(StudentAuthintication.MapConstants.ApiKey, forHTTPHeaderField: "X-Parse-REST-API-Key")
        
        
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            
            guard (error == nil) else {
                
                let userInfo = [NSLocalizedDescriptionKey : "\(error!.localizedDescription)"]
                completionHandlerForGET(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: userInfo))
                return
            }
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                let userError = [NSLocalizedDescriptionKey : "Your request returned a status code other than 2xx!"]
                completionHandlerForGET(nil, NSError(domain: "taskForGETMethod", code: 1, userInfo: userError))
                return
            }
            
            let data = data
            
            self.convertion(data!, decode:decode,completionHandlerForConvertData: completionHandlerForGET)
            
        }
        
        task.resume()
        
        return task
        
        
    }
    
    
    
    func taskForPUTMethod<E: Encodable,D:Decodable>(_ method: String,decode:D.Type?, jsonBody: E, completionHandlerForPUT: @escaping (_ result: AnyObject?, _ error: NSError?) -> Void) -> URLSessionDataTask {
        
        
        var components = URLComponents()
        components.scheme = StudentAuthintication.MapConstants.ApiScheme
        components.host = StudentAuthintication.MapConstants.ApiHost
        components.path = StudentAuthintication.MapConstants.ApiPath + (method)
        
        let request = NSMutableURLRequest(url:components.url!)
        
        
        
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        request.addValue(StudentAuthintication.MapConstants.ApplicationID, forHTTPHeaderField: "X-Parse-Application-Id")
        request.addValue(StudentAuthintication.MapConstants.ApiKey, forHTTPHeaderField: "X-Parse-REST-API-Key")
        
        
        do{
            let JsonBody = try JSONEncoder().encode(jsonBody)
            request.httpBody = JsonBody
            
            
        } catch{
            
            let userError = [NSLocalizedDescriptionKey : "There was an error with your request JSON Body: \(error)"]
            completionHandlerForPUT(nil, NSError(domain: "taskForPUTMethod", code: 1, userInfo: userError))
            
        }
        
        let task = urlSession.dataTask(with: request as URLRequest) { (data, response, error) in
            
            
            guard (error == nil) else {
                
                let userError = [NSLocalizedDescriptionKey : "\(error!.localizedDescription)"]
                completionHandlerForPUT(nil, NSError(domain: "taskForPUTMethod", code: 1, userInfo: userError))
                return
            }
            
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode, statusCode >= 200 && statusCode <= 299 else {
                
                print("Your request returned a status code other than 2xx!")
                let userError = [NSLocalizedDescriptionKey : "Your request returned a status code other than 2xx!"]
                completionHandlerForPUT(nil, NSError(domain: "taskForPUTMethod", code: 1, userInfo: userError))
                
                return
            }
            
            let data = data
            
            self.convertion(data!, decode: decode!, completionHandlerForConvertData: completionHandlerForPUT)
            
        }
        /* 7. Start the request */
        task.resume()
        
        return task
    }
    
    
    
    
    private func convertion<D: Decodable>(_ data: Data,decode:D.Type, completionHandlerForConvertData: (_ result: AnyObject?, _ error: NSError?) -> Void) {
        
        
        
        let obj = try! JSONDecoder().decode(decode, from: data)
        completionHandlerForConvertData(obj as AnyObject, nil)
        
        
        
    }
    
    
    func getAllDataFormUsers(_ completionHandlerForUserID: @escaping (_ success: Bool,_ usersData: [Any]?, _ errorString: String?) -> Void) {
        
        let parameters =  ["limit":"100","order":"-updatedAt"]
        
        
        _ = taskForGETMethod( "/StudentLocation", parameters: parameters as [String : AnyObject] , decode: StudentPosition.self) { (result, error) in
            
            
            if let error = error {
                
                completionHandlerForUserID(false ,nil ,"\(error.localizedDescription)")
            }else {
                let newResult = result as! StudentPosition
                if let usersData = newResult.results  {
                    completionHandlerForUserID(true ,usersData,nil)
                    
                }else {
                    completionHandlerForUserID(false ,nil ,"\( error!.localizedDescription)")
                    
                }
                
                
            }
        }
        
    }
    
    
    func getuserDataByUniqueKey(_ completionHandlerForUserID: @escaping (_ success: Bool,_ objectId:String?, _ errorString: String?) -> Void) {
        
        
        let method: String = "/StudentLocation"
        
        var  newParameterValues :String = ""
        if "{\"uniqueKey\":\"{id}\"}".range(of: "{\("id")}") != nil {
            newParameterValues = "{\"uniqueKey\":\"{id}\"}".replacingOccurrences(of: "{\("id")}", with: StudentAuthintication.sharedInstance().userID!)
        } else {
            newParameterValues = "nil"
        }
        
        
        
        
        let parameters =  ["where":newParameterValues]
        
        
        /* 2. Make the request */
        
        
        _ = taskForGETMethod(method, parameters: parameters as [String : AnyObject], decode: StudentPosition.self) { (result, error) in
            
            
            if let error = error {
                
                completionHandlerForUserID(false ,nil ,"\(error.localizedDescription)")
            }else {
                let newResult = result as! StudentPosition
                
                if !((newResult.results?.isEmpty)!){
                    if let usersData = newResult.results  {
                        
                        // if there is data (user already posted his Location)
                        // get objectId
                        if let objectId = usersData[0].objectId    {
                            MapAutinitication.sharedInstance().objectId = objectId
                            
                            
                        }
                        
                        completionHandlerForUserID(true ,self.objectId,nil)
                    }else {
                        completionHandlerForUserID(false ,nil ,"\( error!.localizedDescription)")
                        
                    }
                    
                }else {
                    completionHandlerForUserID(true ,self.objectId ,nil)
                    
                }
                
                
            }
        }
        
    }
    
    func postUserLocation<E: Encodable>( jsonBody:E ,completionHandlerForSession: @escaping (_ success: Bool , _ errorString: String?) -> Void) {
        
        _ = taskForPUTMethod("/StudentLocation", decode: StudentLocationsResponse.self, jsonBody: jsonBody) { (result, error) in
            
            if let error = error {
                completionHandlerForSession(false ,"\(error.localizedDescription) ")
            }else {
                if result != nil{
                    completionHandlerForSession(true ,nil)
                    
                }else {
                    completionHandlerForSession(false ," \(error!.localizedDescription)")
                    
                }
                
                
            }
        }
        
    }
    
    func putUserLocation<E: Encodable>( jsonBody:E ,completionHandlerForSession: @escaping (_ success: Bool , _ errorString: String?) -> Void) {
        
        
        var mutableMethod: String = "/StudentLocation/{id}"
        
        if mutableMethod.range(of: "{\("id")}") != nil {
            mutableMethod = mutableMethod.replacingOccurrences(of: "{\("id")}", with:  String(self.objectId!))
        } else {
            mutableMethod =  "nil"
        }
        
        
        _ = taskForPUTMethod(mutableMethod, decode: StudentLocationsUpdateResponse.self, jsonBody: jsonBody) { (result, error) in
            
            if let error = error {
                completionHandlerForSession(false ,"\(error.localizedDescription) ")
            }else {
                if result != nil {
                    completionHandlerForSession(true  ,nil)
                    
                }else {
                    completionHandlerForSession(false ," \(error!.localizedDescription)")
                    
                }
                
                
            }
        }
        
    }
    
}
