//
//  ListTableCell.swift
//  OnTheMap
//
//  Created by Mac on 03/05/1440 AH.
//  Copyright © 1440 Udacity. All rights reserved.
//

import UIKit

class ListTableCell: UITableViewCell {
    
    @IBOutlet weak var Name: UILabel!
    
    @IBOutlet weak var URL: UILabel!
    
    func tablCell(userInfo: results) {
        
        let first = userInfo.firstName
        let last = userInfo.lastName
        let url = userInfo.mediaURL
        
        Name.text =  first! + " " + last!
        URL.text = "\(String(describing: url))"
        
    }
    
}
